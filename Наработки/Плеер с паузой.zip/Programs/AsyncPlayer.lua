function SpeakerControl(keyboardReceiver, speaker, decoder, audioPath)
    print(1)
    local audioFile = assert(io.open(audioPath), "No such audiofile")

    local isPaused = true
    local chunk = audioFile:read(6000)
    local chunkNum = 0
    print(2)

    while chunk ~= nil do
        print(3)
        if keyboardReceiver:getKeyFromQueue() == keys.space then
            isPaused = true
        end
        while isPaused do
            if keyboardReceiver:getKeyFromQueue() == keys.space then
                isPaused = false
                break
            end
            os.sleep(0.3)
            print("Audio is paused. Waiting for space to be pressed.")
        end
        speaker.playAudio(decoder(chunk))
        os.pullEvent("speaker_audio_empty")
        print("Now playing ", chunkNum, " chunk")
        chunk = audioFile:read(6000)
        chunkNum = chunkNum + 1
    end
end


local keyboardReceiver = require("KeyboardReceiver")
local dfpwm = require("cc.audio.dfpwm")
local speaker = peripheral.find("speaker")
local decoder = dfpwm.make_decoder()

print(4)

--io.lines("Test.dfpwm", 6000)

parallel.waitForAll(function() SpeakerControl(keyboardReceiver, speaker, decoder, "Test.dfpwm") end,
                    function() keyboardReceiver:startReceiving() end)

