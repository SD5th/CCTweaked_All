local KeyboardReceiver = {first = 0, last = -1, isOn = false}

function KeyboardReceiver:addKeyToQueue(key)
    local last = self.last + 1
    self.last = last
    self[last] = key
end

function KeyboardReceiver:getKeyFromQueue()
    local first = self.first
    if first > self.last then return nil end
    local key = self[first]
    self[first] = nil        -- to allow garbage collection
    self.first = first + 1
    return key
end

function KeyboardReceiver:startReceiving()
    self.isOn = true
    while self.isOn do
        local _, keyCode = os.pullEvent("key_up")
        self:addKeyToQueue(keyCode)
    end
end

function KeyboardReceiver:stopReceiving()
    self.isOn = false
end

function KeyboardReceiver:isEmpty()
    if self.first > self.last then
        return true
    else
        return false
    end
end
return KeyboardReceiver