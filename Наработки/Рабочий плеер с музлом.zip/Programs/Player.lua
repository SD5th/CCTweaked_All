function SpeakerControl(keyRec, speakersList, audioPath)
    local spInt = require("SpeakerInterface")
    spInt:setSpeakersList(speakersList)
    spInt:setAudio(audioPath)

    local isPaused = true
    local chunkNum = 0
    local lastChunkNum = spInt:getLastChunkNum()


    local HandleQueue = function ()
        if keyRec:isSomethingPressed()
        or keyRec:isKeysHeld({keys.up, keys.left, keys.down, keys.right}) 
        or isPaused then
            local chunkNumOffset = 0
            local wasPausePressed = false
            while  keyRec:isSomethingPressed() 
                or keyRec:isKeysHeld({keys.up, keys.left, keys.down, keys.right})
                or isPaused
            do
                if keyRec:isSomethingPressed() then
                    local pressedKeysCombination = keyRec:getKeysCombination()
                    if #pressedKeysCombination == 1 then
                        local pressedKey = pressedKeysCombination[1]
                        if pressedKey == keys.space then
                            spInt:stopSpeakers()
                            wasPausePressed = true
                            if isPaused then
                                isPaused = false
                            else
                                isPaused = true
                            end
                        elseif pressedKey == keys.left or pressedKey == keys.right then
                            spInt:stopSpeakers()
                            if pressedKey == keys.left then
                                chunkNumOffset = chunkNumOffset - 5
                            else
                                chunkNumOffset = chunkNumOffset + 5
                            end
                        elseif pressedKey == keys.up or pressedKey == keys.down then
                            isPaused = true
                            spInt:stopSpeakers()
                            wasPausePressed = true
                            if pressedKey == keys.up then
                                spInt:changeVolume(0.2)
                            else
                                spInt:changeVolume(-0.2)
                            end
                            print("New volume:", spInt.volume)
                        end
                    end
                end
                   
                if keyRec:isKeysHeld({keys.up, keys.left, keys.down, keys.right}) then
                    if keyRec:isKeysHeld({keys.left, keys.right}) then
                        spInt:stopSpeakers()
                        if keyRec:isKeysHeld({keys.left}) then
                            chunkNumOffset = chunkNumOffset - 5
                        else
                            chunkNumOffset = chunkNumOffset + 5
                        end
                    elseif keyRec:isKeysHeld({keys.up, keys.down}) then
                        isPaused = true
                        spInt:stopSpeakers()
                        wasPausePressed = true
                        if keyRec:isKeysHeld({keys.up}) then
                            spInt:changeVolume(0.2)
                        else
                            spInt:changeVolume(-0.2)
                        end
                        print("New volume:", spInt.volume)
                    end
                    sleep(0.2)
                end

                if isPaused then
                    while not keyRec:isSomethingPressed() 
                      and not keyRec:isKeysHeld({keys.up, keys.left, keys.down, keys.right}) 
                    do
                        os.sleep(0)
                    end
                end
            end
                
            if wasPausePressed and chunkNumOffset == 0 then
                chunkNumOffset = chunkNumOffset - 2
            end

            chunkNum = chunkNum + chunkNumOffset
            if chunkNum < 0 then
                chunkNum = 0
            elseif chunkNum > lastChunkNum then
                chunkNum = lastChunkNum
            end

        end
    end

    HandleQueue()

    while chunkNum <= lastChunkNum do
        term.clear()
        term.setCursorPos(1,1)
        print("Now playing:", chunkNum, "chunk, Volume:", spInt.volume)
        spInt:playChunk(chunkNum)
        os.pullEvent("chunk is played")
        chunkNum = chunkNum + 1

        HandleQueue()
    end
end

local speakersList = { peripheral.find("speaker") }
local currentPath = "/"
while true do
    local audioPath
    local isAudioFound = false
    while not isAudioFound do
        term.clear()
        term.setCursorPos(1,1)
        local pathOptions = fs.list(currentPath)
        for i, v in pairs(pathOptions) do
            print(i, "|", v)
        end
        print()
        print("Enter your choice.")
        local userChoice = read()
        if fs.exists(currentPath .. userChoice) then
            print("exists")
            if fs.isDir(currentPath .. userChoice) then
                print("isDir")
                currentPath = currentPath .. userChoice .. "/"
            else
                print("notDir")
                if string.find(userChoice, ".dfpwm") ~= nil then
                    print("audioFound")
                    isAudioFound = true
                    audioPath = currentPath .. userChoice
                end
            end
        end 
    end

    term.clear()
    term.setCursorPos(1,1)
    print("Press Space")
    local keyboardReceiver = require("KeyboardReceiver")
    parallel.waitForAny(function() SpeakerControl(keyboardReceiver, speakersList, audioPath) end,
                        function() keyboardReceiver:startReceiving() end)
    keyboardReceiver:stopReceiving()
    
end