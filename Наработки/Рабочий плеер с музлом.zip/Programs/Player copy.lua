local keyboardReceiver = require("KeyboardReceiver")
local dfpwm = require("cc.audio.dfpwm")
local speaker = peripheral.find("speaker")


function SpeakerControl(keyboardReceiver, speaker, decoder, audioPath)
    
    local audioFile = assert(io.open(audioPath), "No such audiofile")

    local isPaused = true
    local chunkNum = 0

    local HandleQueue = function ()
        if not keyboardReceiver:isEmpty() or isPaused then
            --speaker.stop()
            local chunkNumOffset = 0
            local wasPausePressed = false
            while not keyboardReceiver:isEmpty() or isPaused do
                local pressedKey = keyboardReceiver:getKeyFromQueue()
                if pressedKey == keys.space then
                    if isPaused then
                        isPaused = false
                    else
                        isPaused = true
                    end
                    wasPausePressed = true
                elseif pressedKey == keys.left then
                    chunkNumOffset = chunkNumOffset - 5
                elseif pressedKey == keys.right then
                    speaker.stop()
                    chunkNumOffset = chunkNumOffset + 5
                end
                --print(pressedKey, keys.getName(pressedKey))
                sleep(0)
                print("another cycle")
            end
            if wasPausePressed and chunkNumOffset == 0 then
                chunkNumOffset = chunkNumOffset - 2
            end
            chunkNum = chunkNum + chunkNumOffset
            if chunkNum < 0 then
                chunkNum = 0
            end
            
        end
    end

    HandleQueue()
    audioFile:seek("set", chunkNum * 6000)
    local chunk = audioFile:read(6000)

    while chunk ~= nil do
        print("Now playing ", chunkNum, " chunk")
        speaker.playAudio(decoder(chunk))
        os.pullEvent("speaker_audio_empty")
        chunkNum = chunkNum + 1

        HandleQueue()
        audioFile:seek("set", chunkNum * 6000)
        chunk = audioFile:read(6000)

    end
end

local decoder = dfpwm.make_decoder()


--io.lines("Test.dfpwm", 6000)

parallel.waitForAll(function() SpeakerControl(keyboardReceiver, speaker, decoder, "Test.dfpwm") end,
                    function() keyboardReceiver:startReceiving() end)--,
                    --function() while true do local event = os.pullEvent("speaker_audio_empty") print(event) end end)